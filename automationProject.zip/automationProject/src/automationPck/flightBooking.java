package automationPck;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;  


public class flightBooking {
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\chromedriver\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();  
		 //WebDriverWait myWait=new WebDriverWait (driver,10);
       
		 for (int i=0;i<=5;i++)
	    {
			 // Launch URL
			 driver.navigate().to("http://blazedemo.com/");  
        
			 //Maximize the browser  
			 driver.manage().window().maximize();
			 	 
			 WebDriverWait wait = new WebDriverWait(driver,3);
		      // presenceOfElementLocated condition
			 wait.until(ExpectedConditions.presenceOfElementLocated (By.xpath("//input[@value='Find Flights']")));
        
			 	 System.out.println("Loop value:"+i);
        		 Select srcDropdown = new Select(driver.findElement(By.name("fromPort")));  
        	     srcDropdown.selectByIndex(i);
        	        
        	     Select destiDropdown = new Select(driver.findElement(By.name("toPort"))); 
        	     destiDropdown.selectByIndex(i+1);
        	     driver.findElement(By.xpath("//input[@value='Find Flights']")).click();
        	     
        	    // driver.findElements(By.xpath("//input[@value='Choose This Flight']")).get(i).click();
				  if(i==0) {
				  driver.findElements(By.xpath("//input[@value='Choose This Flight']")).get(i+1).click(); 
				  }
				  
				  else if(i==1) {
				  driver.findElements(By.xpath("//input[@value='Choose This Flight']")).get(i+2).click(); 
				  }
				  
				  else if(i==2) {
				  driver.findElements(By.xpath("//input[@value='Choose This Flight']")).get(i+2).click(); 
				  }
				  
				  else {
				  //Select cheapest Flight
				  driver.findElements(By.xpath("//input[@value='Choose This Flight']")).get(2).click();
				  }

        	        //Fill Customer Details
        	        driver.findElement(By.id("inputName")).sendKeys("Demo");
        	        driver.findElement(By.id("address")).sendKeys("87 Main st");
        	        driver.findElement(By.id("city")).sendKeys("ABC");
        	        driver.findElement(By.id("state")).sendKeys("LA");
        	        driver.findElement(By.id("zipCode")).sendKeys("4567");
        	        //Select Card type
        	        Select cardType = new Select(driver.findElement(By.name("cardType"))); 
        	        cardType.selectByIndex(1);
        	        driver.findElement(By.id("creditCardNumber")).sendKeys("2214335457668798");
        	        driver.findElement(By.id("creditCardMonth")).sendKeys("05");
        	        driver.findElement(By.id("creditCardYear")).sendKeys("2022");
        	        driver.findElement(By.id("nameOnCard")).sendKeys("Demo User");
        	        
        	        //Purchase Flight ticket
        	        driver.findElement(By.xpath("//input[@value='Purchase Flight']")).click();
        	        
        	        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        	        
        	        //Confirm Booking Message
        	        WebElement successMsg=driver.findElement(By.xpath("//*[text()='Thank you for your purchase today!']"));
        	        System.out.println("Element present having text:" + successMsg.getText());
        	        
        	        Assert.assertTrue(driver.findElement(By.xpath("//*[text()='Thank you for your purchase today!']")).isDisplayed());
        	        
        	        //Get Booking confirmation ID
        	        String bookingid=driver.findElement(By.xpath("//table/tbody/tr/td[2]")).getText();        	        
        	        System.out.println("Customer Booking id:"+bookingid);
        	
        }
        
		    //Close open window
                driver.close();
 	}

}
